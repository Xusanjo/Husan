class BankAccount {
    constructor(ownerName,balance,accountNumber){
        this.ownerName=ownerName;
        this.balance=balance;
        this.accountNumber=accountNumber;
    }

    deposit(qushilganPul){
        this.balance+=qushilganPul
        return this.balance
    }
    withdraw(yechilganPul){
        if(yechilganPul<this.balance){
            return this.balance-=yechilganPul
        }else{
            return `Hisobingzida mablag yetarli emas`
        }
    }
    showBalance(){
        return `Kartangizdagi ${this.balance} joriy balans`
    }
}

const bankaccount=new BankAccount('Rustam Jumadullayev',1_000_000,'+998991234567')
console.log(bankaccount.deposit(1_000_000))
console.log(bankaccount.withdraw(500_000))
console.log(bankaccount.showBalance())