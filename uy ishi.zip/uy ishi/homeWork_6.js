function squarNumber(n){
    let num=0
    let k = 1

    // 1-usul
    while(n>0){
        let son=n%10;
        let kv=son**2;
        num+=kv*k;
        n=Math.floor(n/10);
        k*=10
    }
    // 2-usul
    // let k = n + ''
    // for (let index = 0; index < k.length; index++) {
    //     num+=k[index] ** 2        
    // }
    return num
}

console.log(squarNumber(3221))