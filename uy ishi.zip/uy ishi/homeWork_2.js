function Paskal(numRows) {
    let s = [[1]]
    for(let i = 0; i<numRows-1; i++){
        let g = [1]
        for (let j = 0; j<s[i].length-1; j++){
            let ms = s[i][j] + s[i][j+1]
            g.push(ms)
        }
        g.push(1)
        s.push(g)
    }
    return s
};

console.log(Paskal(5))
