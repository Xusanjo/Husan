class BookList {
    books=[];
    favoritebook='';
    constructor(title, author){
        this.title=title;
        this.author=author;
    }
    addBook(title,author){
        const book={title:title,author:author}
        this.books.push(book)
        // console.log(this.books)
    }
    setFavoriteBook(title){
        this.favoritebook = title
        // console.log(this.favoritebook)
    }
    getBooksList(){
        console.log('Kitoblar Ruyxati:')
        this.books.forEach(book =>{
            console.log(`title:${book.title} author: ${book.author}`)
        })
    }
    getFavoriteBook(){
        console.log(this.favoritebook)
    }
}




const booklists=new BookList()
booklists.addBook("To Kill a Mockingbird",'Harper Lee');
booklists.addBook("1984", 'George Orwell');

booklists.setFavoriteBook('1984')

booklists.getBooksList()
booklists.getFavoriteBook()