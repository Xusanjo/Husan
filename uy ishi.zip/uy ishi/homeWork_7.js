class Box {
    constructor(length,width,height){
        this.length=length;
        this.width=width;
        this.height=height;
    }
    totalVolume(length,width,height){
        return length+width+height
    }
    getVolume(length,width,height){
        return length*width*height
    }
}

const box=new Box()
console.log(box.totalVolume(4,8,4))
console.log(box.getVolume(4,4,8))
