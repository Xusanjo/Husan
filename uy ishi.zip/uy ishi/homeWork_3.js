class Magic {
    replace(a,b){
        console.log(`a:${a}, b:${b}`)
        let c=a;
        a=b;
        b=c
        console.log(`a:${a}, b:${b}`)
    }

    length(data){
        let count=0;
        // har qanday data bersak ham uni uzunligini qaytarsin
        for(let i=0; i<data.length; i++){
            count++
        }
        console.log(`${data} -> uzunligi: ${count}`)
    }

    toUpperCase(str){
        let k = ''
        //  stringni Katta harflar bilan yozadigan qilsin buni o'ziz yozib chiqing tayyor codedan yoki string methotidan foydalanman
        let obj = {
        "a":"A", "b":"B", "c":"C", "d":"D", "e":"E", "f":"F",
        "g":"G", "h":"H", "i":"I", "j":"J", "k":"K", "l":"L",
        "m":"M", "n":"N", "o":"O", "p":"P", "q":"Q", "s":"S",
        "t":"T", "u":"U", "v":"V", "w":"W", "x":"X", "y":"Y",
        "z":"Z"
        }
        for(let i=0; i<str.length; i++){
            for (const iterator in obj) {
                if(str[i]==iterator){
                    k+=obj[iterator]
                }
            }
        }
        console.log(k)  
    }

    repeat(data,n){
        let natija=''
        for(let i=0; i<n; i++){
            natija+=data
        }
        console.log(natija)
    }
    count(str){

    }
}


const magic=new Magic()
magic.replace(5,8)
magic.length('nimadir')
magic.toUpperCase('qwertyuiop')
magic.repeat('hi',2)